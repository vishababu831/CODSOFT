package com.codsoft.task4;
import java.util.Scanner;

public class CurrencyConverter {
	public static void main(String[] args) {
		        Scanner sc = new Scanner(System.in);

		        double amount, result = 0;
		        int choiceFrom, choiceTo;

		        System.out.println("===== Currency Converter =====");
		        System.out.println("1. INR");
		        System.out.println("2. USD");
		        System.out.println("3. EUR");

		        System.out.print("Choose base currency (1-3): ");
		        choiceFrom = sc.nextInt();

		        System.out.print("Choose target currency (1-3): ");
		        choiceTo = sc.nextInt();

		        System.out.print("Enter amount: ");
		        amount = sc.nextDouble();

		        // Convert base currency to INR
		        double amountInINR = 0;

		        if (choiceFrom == 1)
		            amountInINR = amount;
		        else if (choiceFrom == 2)
		            amountInINR = amount * 83;
		        else if (choiceFrom == 3)
		            amountInINR = amount * 90;
		        else
		            System.out.println("Invalid base currency");

		        // Convert INR to target currency
		        if (choiceTo == 1)
		            result = amountInINR;
		        else if (choiceTo == 2)
		            result = amountInINR / 83;
		        else if (choiceTo == 3)
		            result = amountInINR / 90;
		        else
		            System.out.println("Invalid target currency");

		        System.out.println("Converted Amount: " + result);

		        sc.close();
		    }
		

	}
