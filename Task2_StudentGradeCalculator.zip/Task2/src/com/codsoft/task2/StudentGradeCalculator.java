/**
 * 
 */
package com.codsoft.task2;

/**
 * 
 */
import java.util.Scanner;
public class StudentGradeCalculator {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter number of Subject:");
		int subjects=sc.nextInt();
		int totalMarks=0;
		for(int i=1;i<=subjects;i++) {
			System.out.print("Enter marks for subjects"+i+":");
			int marks=sc.nextInt();
			totalMarks+=marks;
		}
		double average=(double)totalMarks/subjects;
		System.out.println("\n Result Summary");
		System.out.println("Total Marks:"+totalMarks);
		System.out.println("Average Percentage:"+average+"%");
		if(average>=90) {
			System.out.println("Grade:A");}
			else if(average>=80) {
				System.out.println("Grade:B");
			}
			else if(average>=70) {
				System.out.println("Grade:C");
			}
			else if(average>=60) {
				System.out.println("Grade:D");}
			else {
				System.out.println("Grade:F");}
		sc.close();}}
