package com.codsoft.task3;
import java.util.Scanner;
public class ATMInterface {
static double balance=10000;
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int choice;
	System.out.println("Welcome to Codsoft ATM");
	do {
		System.out.println("\n-------------Menu----------------");
		System.out.println("1.Check Balance");
		System.out.println("2.Deposit Money");
		System.out.println("3.Withdraw Money");
		System.out.println("4.Exit");
		System.out.println("Enter your choice:");
		choice =sc.nextInt();
		switch (choice) {
		case 1:
		System.out.println("Your current balance is:"+balance);
		break;
		case 2:
		System.out.println("Enter amount to deposit:");
		double deposit=sc.nextDouble();
		if(deposit>0) {
			balance +=deposit;
			System.out.println("Amount deposited successfully.");
		}
		else {
			System.out.println("Invalid deposit amount.");
		}break;
		case 3:
			System.out.println("Thank you for using CodSoft ATM!");
			break;
			default:
				System.out.println("Invalid choice.Please try again.");
		}
	}
	while(choice!=4);
	sc.close();
		}
		}